﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UçakBiletRezervasyon.Models
{
    public class Ucak
    {
        public int id { get; set; }
        public string Model { get; set; }
        public string Marka { get; set; }
        public int SeriNo { get; set; }
        public int KoltukKapasite { get; set; }

    }
}
